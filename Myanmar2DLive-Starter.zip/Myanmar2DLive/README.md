# Myanmar 2D Live — Android starter project

This is a native Android / Kotlin / Jetpack Compose starter app with:
- Live screen (today's morning and evening result)
- Admin entry screen
- History screen
- Local persistence with SharedPreferences

**Important:** This starter is an offline prototype. Results are manually entered and stored on one device. It does NOT connect to a verified live result source or sync across devices. The demo PIN `1234` is hardcoded and is NOT secure; do not publish this as-is. Before public release, replace demo authentication with Firebase Authentication and enforce admin permissions in Firestore security rules or a trusted backend. Only display results you are authorized to republish and comply with applicable local laws.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this `Myanmar2DLive` folder in Android Studio.
3. Let Gradle sync complete; use JDK 17 if prompted.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run to install a debug build.
6. To create an installable debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the output path.

## Next production steps
1. Create a Firebase project and add the Android app ID `com.example.myanmar2dlive`.
2. Add Firebase Authentication and sign-in for admins.
3. Store results in Cloud Firestore, with security rules allowing only authorized admins to write.
4. Use a listener to update the Live and History screens in real time.
5. Test date/time-zone handling, error states, backups, and access rules before release.
