package com.example.myanmar2dlive

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ResultItem(val date: String, val session: String, val number: String, val updated: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF075E54))) { TwoDApp(this) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TwoDApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("two_d_live", Context.MODE_PRIVATE) }
    fun loadResults(): List<ResultItem> {
        val arr = runCatching { JSONArray(prefs.getString("results", "[]")) }.getOrElse { JSONArray() }
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i)
            ResultItem(o.getString("date"), o.getString("session"), o.getString("number"), o.getString("updated"))
        }.getOrNull() }.sortedByDescending { it.updated }
    }
    var results by remember { mutableStateOf(loadResults()) }
    var tab by remember { mutableIntStateOf(0) }
    fun saveResult(session: String, number: String) {
        val now = Date()
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(now)
        val newItem = ResultItem(date, session, number, time)
        // Keep a single current result per date/session; preserve other history.
        val updated = (listOf(newItem) + results.filterNot { it.date == date && it.session == session })
            .sortedByDescending { it.updated }
        val arr = JSONArray()
        updated.forEach { item -> arr.put(JSONObject().put("date", item.date).put("session", item.session).put("number", item.number).put("updated", item.updated)) }
        prefs.edit().putString("results", arr.toString()).apply()
        results = updated
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("မြန်မာ 2D Live", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Live") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("မှတ်တမ်း") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Admin") })
            }
        }
    ) { padding ->
        when (tab) {
            0 -> LiveScreen(results, Modifier.padding(padding))
            1 -> HistoryScreen(results, Modifier.padding(padding))
            else -> AdminScreen(Modifier.padding(padding), onSave = { session, number -> saveResult(session, number) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LiveScreen(results: List<ResultItem>, modifier: Modifier = Modifier) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val am = results.firstOrNull { it.date == today && it.session == "မနက်ပိုင်း" }
    val pm = results.firstOrNull { it.date == today && it.session == "ညနေပိုင်း" }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("ယနေ့ 2D ရလဒ်", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("ရက်စွဲ: $today", color = MaterialTheme.colorScheme.onSurfaceVariant)
        ResultCard("မနက်ပိုင်း", am)
        ResultCard("ညနေပိုင်း", pm)
        Text("မှတ်ချက် - ဒီ App က Admin ထည့်ထားတဲ့ ရလဒ်ကိုသာ ပြသပါတယ်။ အလိုအလျောက် Live data ချိတ်ဆက်ထားခြင်း မရှိသေးပါ။", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ResultCard(title: String, item: ResultItem?) {
    Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(item?.number ?: "--", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Text(if (item == null) "ရလဒ် မထည့်ရသေးပါ" else "နောက်ဆုံးပြင်ဆင်ချိန် ${item.updated}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun HistoryScreen(results: List<ResultItem>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("ရလဒ်မှတ်တမ်း", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (results.isEmpty()) {
            Text("မှတ်တမ်းမရှိသေးပါ။ Admin မှ ရလဒ်ထည့်ပါ။", modifier = Modifier.padding(top = 12.dp))
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results, key = { "${it.date}-${it.session}" }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.date, fontWeight = FontWeight.Bold)
                            Text(item.session, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(item.number, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminScreen(modifier: Modifier = Modifier, onSave: (String, String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var authenticated by remember { mutableStateOf(false) }
    var session by remember { mutableStateOf("မနက်ပိုင်း") }
    var number by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Admin Panel", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (!authenticated) {
            Text("စမ်းသပ်ရန် Demo PIN: 1234", color = MaterialTheme.colorScheme.error)
            OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8) }, label = { Text("Admin PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
            Button(onClick = { authenticated = pin == "1234"; message = if (authenticated) "ဝင်ရောက်ပြီးပါပြီ" else "PIN မှားနေပါတယ်" }, modifier = Modifier.fillMaxWidth()) { Text("ဝင်မယ်") }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
            Text("သတိ: ဒီ PIN က Demo အတွက်သာဖြစ်ပြီး လုံခြုံသော Admin authentication မဟုတ်ပါ။ Public app မထုတ်ခင် Firebase Authentication နှင့် server-side permission ထည့်ပါ။", style = MaterialTheme.typography.bodySmall)
        } else {
            Text("Session ရွေးပါ")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = session == "မနက်ပိုင်း", onClick = { session = "မနက်ပိုင်း" }, label = { Text("မနက်ပိုင်း") })
                FilterChip(selected = session == "ညနေပိုင်း", onClick = { session = "ညနေပိုင်း" }, label = { Text("ညနေပိုင်း") })
            }
            OutlinedTextField(value = number, onValueChange = { number = it.filter(Char::isDigit).take(2) }, label = { Text("2D ဂဏန်း (00–99)") }, placeholder = { Text("ဥပမာ 27") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (number.length == 2) { onSave(session, number); message = "$session ရလဒ် $number ကို သိမ်းပြီးပါပြီ"; number = "" }
                else message = "ဂဏန်း ၂ လုံး အပြည့်ထည့်ပါ။"
            }, modifier = Modifier.fillMaxWidth()) { Text("ရလဒ် သိမ်းမယ်") }
            OutlinedButton(onClick = { authenticated = false; pin = "" }, modifier = Modifier.fillMaxWidth()) { Text("ထွက်မယ်") }
            if (message.isNotBlank()) Text(message)
        }
    }
}
